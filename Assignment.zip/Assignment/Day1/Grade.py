   
marks=int(input("Enter marks"))
if marks>90:
    print("Distinction")
elif (marks<90) and (marks>80):
    print("Average")
else:
    print("Below average")


