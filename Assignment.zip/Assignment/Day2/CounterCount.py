count = 0
def counter():
    global count
    count += 1
    print(count)


counter()
counter()
counter()
counter()
counter()

 # Using Global variable it is not safe to use